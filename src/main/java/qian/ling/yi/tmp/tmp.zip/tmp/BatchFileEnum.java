package qian.ling.yi.tmp;

/**
 * 批量文件类型
 * Created by liuguobin on 2016/12/30.
 */
public enum BatchFileEnum {
    auth("auth"),
    authRes("-BAUTH1001RES-"),
    authZxRes("-APPZX1001RES-"),
    appZx(""),
    appZxRes("-APPZX1001RES-"),
    eve("-EVE1001"),
    alEve("-ALEVE1001-"),
    trdPayEve("-TRDPAYEVE-"),
    bid(""),
    bidRes("-BIDRESP-"),
    finTran(""),
    finTranRes("-FINTRAN-RESULT-"),
    repTran(""),
    repTranRes("-REPTRAN-RESULT-"),
    trQt(""),
    trQtRes("-TRQTRES-"),
    trnCr(""),
    trnCrRes("-TRNCRRES-"),
    sigTran(""),
    sigRes("-SIGRES-");

    private String fileName ;
    BatchFileEnum(String fileName) {
        this.fileName = fileName;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

}
