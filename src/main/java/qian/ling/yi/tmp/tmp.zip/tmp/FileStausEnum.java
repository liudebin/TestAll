package qian.ling.yi.tmp;

/**
 * Created by liuguobin on 2017/2/25.
 */
public enum FileStausEnum {

        INIT, // 初始化任务
        CREATE_SUC, //  创建成功
        CREATE_FAIL, // 创建失败
        UPLOAD_SUC, // 上传成功
        UPLOAD_FAIL, // 上传失败
        DOWN_SUC, // 下载成功
        DOWN_FAIL // 下载失败
}
