package qian.ling.yi.tmp;

import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.io.FileInputStream;
import java.io.UnsupportedEncodingException;
import java.util.*;

/**
 * ftp文件工具
 * Created by liuguobin on 2016/12/26.
 */
@Component
public class FtpFileBuilder {
    private Logger logger = LoggerFactory.getLogger(FtpFileBuilder.class);

    /**
     * 创建本地文件
     *
     * @param localPath
     * @param confFile
     * @param values
     * @param fails
     * @return
     */
    public boolean createFile(String localPath, String confFile, List<Map<String, String>> values, List<Map<String, String>> fails) {
        List<String> lineValue = concatList(confFile, values, fails);
        if (null == lineValue || lineValue.isEmpty()) {
            logger.info("列表为空 {}", localPath);
            return false;
        }

        return FileUtil.writeAsList(lineValue, localPath, "gbk");
    }

    /**
     * 根据编码格式读取文件
     *
     * @param localFile
     * @param confFile
     * @param values
     * @param fails
     * @return
     */
    public boolean readCharsetFile(String localFile, String confFile, List<Map<String, String>> values, List<String> fails, String charset) {
        LinkedList<String> fileLine = new LinkedList<>();
        if (!FileUtil.readAsList(fileLine, localFile, charset)) {
            logger.error("文件读取错误：{}", localFile);
            return false;
        }
        values.addAll(str2List(confFile, fileLine, fails, charset));
        return values.size() != 0;
    }

    /**
     * 根据配置文件拼接数据列表
     *
     * @param xmlConfFile
     * @param values
     * @param fail
     * @return
     */
    private List<String> concatList(String xmlConfFile, List<Map<String, String>> values, List<Map<String, String>> fail) {
        LinkedHashMap<String, Map<String, String>> confMap = readConf(xmlConfFile);
        if (null == confMap || confMap.isEmpty()) {
            logger.error("读取配置文件 - {} 出错", xmlConfFile);
            return null;
        }
        List<String> lines = new ArrayList<>(values.size());
        for (Map<String, String> value : values) {
            StringBuilder line = new StringBuilder();
            if (concatMapStr(confMap, line, value)) {
                lines.add(line.append("\n").toString());
            } else {
                fail.add(value);
            }
        }
        return lines;
    }


    /**
     * 根据字段属性拼接字符串
     *
     * @param confMap 字段属性
     * @param line    拼接后字符串
     * @param value   要拼接的Map
     * @return boolean
     */
    private boolean concatMapStr(LinkedHashMap<String, Map<String, String>> confMap, StringBuilder line, Map<String, String> value) {
        for (String key : confMap.keySet()) {
            Map<String, String> keyConf = confMap.get(key);
            if (!StringUtil.appendAndFill(line, value.get(key), keyConf.get("type"), Integer.parseInt(keyConf.get("length")))) {
                logger.warn("{} 字段长度超限 value - {}", key, value.get(key));
                return false;
            }
        }
        return true;
    }

    /**
     * 根据配置文件读取数据列表
     *
     * @param xmlConfFile 配置文件
     * @param values      原始数据
     * @param fail        错误数据
     * @return List
     */
    private List<Map<String, String>> str2List(String xmlConfFile, List<String> values, List<String> fail, String charset) {
        LinkedHashMap<String, Map<String, String>> confMap = readConf(xmlConfFile);
        if (null == confMap || confMap.isEmpty()) {
            logger.error("读取配置文件出错 - {}", xmlConfFile);
            return new ArrayList<>();
        }
        List<Map<String, String>> lines = new ArrayList<>();
        try {
            parseStr(values, fail, charset, confMap, lines);
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        return lines;
    }

    /**
     * 根据配置解析相应编码字节
     * @param values
     * @param fail
     * @param charset
     * @param confMap
     * @param lines
     * @throws UnsupportedEncodingException
     */
    private void parseStr(List<String> values, List<String> fail, String charset, LinkedHashMap<String, Map<String, String>> confMap, List<Map<String, String>> lines) throws UnsupportedEncodingException {
        for (String value : values) {
            Map<String, String> valueMap = new HashMap<>();
            if (read2Map(value, confMap, valueMap, charset)) {
                lines.add(valueMap);
            } else {
                fail.add(value);
            }
        }
    }

    /**
     * 将字符串根据字段属性分解成Map
     *
     * @param str      字符串
     * @param confMap  字段属性
     * @param valueMap 分解的到的Map
     * @return boolean
     */
    private boolean read2Map(String str, LinkedHashMap<String, Map<String, String>> confMap, Map<String, String> valueMap, String charset) throws UnsupportedEncodingException{
        byte[] value = str.getBytes(charset);

        for (String key : confMap.keySet()) {
            Map<String, String> keyConf = confMap.get(key);
            String keyValue = new String(Arrays.copyOfRange(value, Integer.parseInt(keyConf.get("startIndex")), Integer.parseInt(keyConf.get("endIndex"))), charset);
//            String keyValue = str.substring(Integer.parseInt(keyConf.getById("startIndex")), Integer.parseInt(keyConf.getById("endIndex")));
            if ("1".equals(keyConf.get("type"))) {
                keyValue = keyValue.trim();
            } else {
                if (!keyValue.matches("\\d*"))
                    return false;
                keyValue = StringUtil.rmForeZero(keyValue);
            }
            valueMap.put(key, keyValue);
        }
        return true;
    }

    /**
     * 从文件中读取字段属性配置
     *
     * @param xmlConfFile 配置文件
     * @return LinkedHashMap
     */
    private LinkedHashMap<String, Map<String, String>> readConf(String xmlConfFile) {
        Document document = null;
        try (FileInputStream fis = new FileInputStream(xmlConfFile)) {
            SAXReader reader = new SAXReader();
            document = reader.read(fis);
        } catch (Exception e) {
            logger.error("将文件[{}]转换成Document异常 {}", xmlConfFile, e);
            return null;
        }

        Element el_root = document.getRootElement();//向外取数据，获取xml的根节点。
        LinkedHashMap<String, Map<String, String>> map = new LinkedHashMap<>();
        DomUtil.elementToMap(el_root, map);
        return map;
    }
}
