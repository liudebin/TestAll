package qian.ling.yi.tmp;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.util.List;

/**
 * 文件相关方法
 * Created by liuguobin on 2017/1/4.
 */
public class FileUtil {
    public static Logger logger = LoggerFactory.getLogger(FileUtil.class);

    /**
     * 行写入文件
     * @param lineValues 数据列表
     * @param filePath 本地文件
     * @param encode 编码格式
     * @return boolean
     */
    public static boolean writeAsList(List<String> lineValues, String filePath, String encode) {
        File file = new File(filePath);
        if (!file.exists()) {
            if (!createFile(filePath)) {
                logger.info("写文件 - {} 出错", filePath);
                return false;
            }
        }

        try (FileOutputStream fOut = new FileOutputStream(filePath, true);
             OutputStreamWriter outWriter = new OutputStreamWriter(fOut,encode);
             BufferedWriter bufferedWriter = new BufferedWriter(outWriter)) {

            for (String line : lineValues){
                bufferedWriter.write(line);
            }
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * 行读取文件
     * @param lineValues 读取的数据列表
     * @param filePath 本地文件
     * @param encode 编码格式
     * @return boolean
     */
    public static boolean readAsList(List<String> lineValues, String filePath, String encode) {

        try (FileInputStream fIn = new FileInputStream(filePath);
             InputStreamReader inReader = new InputStreamReader(fIn, encode);
             BufferedReader reader = new BufferedReader(inReader)) {
            String data = null;
            while ((data = reader.readLine()) != null) {
                lineValues.add(data);
            }
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * 创建深目录文件
     * @param filePath 文件路径
     * @return
     */
    public static boolean createFile(String filePath) {
        if (StringUtil.isEmpty(filePath)) {
            logger.info("文件名为空");
            return false;
        }

        File file = new File(filePath);
        if (file.exists()) {
            return true;
        }

        if (filePath.contains("/")) {
            String dir = filePath.substring(0, filePath.lastIndexOf("/"));
            File dirFile = new File(dir);
            if (!dirFile.exists() && !dirFile.mkdirs()) {
                return false;
            }
        }

        try {
            return file.createNewFile();
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }
}
