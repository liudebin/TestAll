package qian.ling.yi.tmp;


import org.springframework.util.StringUtils;

import java.util.Random;

/**
 * Created by baochunyu on 2016/8/4.
 */
public class StringUtil {

    public static boolean isEmpty(String str) {
        return StringUtils.isEmpty(str);
    }

    public static boolean isNotEmpty(String str) {
        return !isEmpty(str);
    }

    public static String convertNull(String str) {
        if (isEmpty(str)) {
            return "";
        } else {
            return str;
        }
    }

    //首字母大写
    public static String captureName(String name) {
        //name = name.substring(0, 1).toUpperCase() + name.substring(1);
        //return  name;
        char[] cs = name.toCharArray();
        cs[0] -= 32;
        return String.valueOf(cs);

    }

    /**
     * unicode编码 转 中文
     *
     * @param ascii unicode编码字符串
     * @return String
     */
    public static String ascii2native(String ascii) {
        int n = ascii.length() / 6;
        StringBuilder sb = new StringBuilder(n);
        for (int i = 0, j = 2; i < n; i++, j += 6) {
            String code = ascii.substring(j, j + 4);
            char ch = (char) Integer.parseInt(code, 16);
            sb.append(ch);
        }
        return sb.toString();
    }

    public static String fillZeroToLeft(int length, int maxLength) {
        String str = "";
        for (int i = 0; i < maxLength - length; i++) {
            str = str + "0";
        }
        return str + String.valueOf(length);
    }

    public static String rmForeZero(String str) {
        if (isEmpty(str)) {
            return "0";
        }

        for (int i=0; i< str.length(); i ++) {
            if (str.charAt(i) != '0') {
                return str.substring(i);
            }
        }
        return "0";
    }

    public static String formatHsAmount(String str) {
        if (isEmpty(str)) {
            return "0";
        }
        return rmForeZero(str);
    }

    public static boolean appendAndFill(StringBuilder strBil, String str, String type, int maxLength) {
        return "1".equals(type) ? appendStrAndFill(strBil, str, maxLength) : appendNumAndFill(strBil, str, maxLength);
    }

    /**
     * 追加字符串，位数不过补" "
     * @param strBil
     * @param str
     * @param maxLength
     * @return
     */
    public static boolean appendStrAndFill(StringBuilder strBil, String str, int maxLength) {
        int fillLength = maxLength;
        if (isNotEmpty(str)) {
            if (str.length() > maxLength) {
                return false;
            }
            fillLength = maxLength - str.length();
            try {
                fillLength = maxLength - str.getBytes("GBK").length;
            } catch (Exception e) {
                e.printStackTrace();
                return false;
            }

            strBil.append(str);
        }
        for (int i = 0; i < fillLength; i ++) {
            strBil.append(" ");
        }

        return true;
    }

    /**
     * 追加数字，位数不够左侧追加"0"
     * @param strBil
     * @param str
     * @param maxLength
     * @return
     */
    public static boolean appendNumAndFill(StringBuilder strBil, String str, int maxLength) {
        int fillLength = maxLength;
        if (isNotEmpty(str)) {
            if (str.length() > maxLength) {
                return false;
            }
            fillLength = maxLength - str.length();
        } else {
            str = "";
        }
        for (int i = 0; i < fillLength; i ++) {
            strBil.append("0");
        }
        strBil.append(str);

        return true;
    }

    public static void main(String args[]) {
        System.out.println(captureName("acdb"));
        String a = "0000123";
        System.out.println(Integer.parseInt(a));
        StringBuilder sb = new StringBuilder("12");
        appendNumAndFill(sb, "123", 6);
        System.out.println(sb);
        appendStrAndFill(sb, "123", 6);
        System.out.println(sb);
        System.out.println(rmForeZero("0.00"));
    }

    private static String[] telFirst="134,135,136,137,138,139,150,151,152,157,158,159,130,131,132,155,156,133,153".split(",");
    public static String createTel() {
        int index=getNum(0,telFirst.length-1);
        String first=telFirst[index];
        String second=String.valueOf(getNum(1,888)+10000).substring(1);
        String thrid=String.valueOf(getNum(1,9100)+10000).substring(1);
        return first+second+thrid;
    }
    public static int getNum(int start,int end) {
        return (int)(Math.random()*(end-start+1)+start);
    }

    /**
     * 生成银行卡号
     */
    public static String createBankCard(String bankType) {
        String cardNo = "";
        String bankCode ;
        while (true) {
            StringBuilder sb = null;
            if(bankType.equals("ICBC") ||bankType.equals("CCB") ||bankType.equals("ABC") || bankType.equals("PSBC") || bankType.equals("BCOM") || bankType.equals("GDB")|| bankType.equals("BOC")){
                sb = new StringBuilder(13);
                for(int j = 0; j < 13; j++){
                    sb.append(new Random().nextInt(10));
                }
            }else{
                sb = new StringBuilder(10);

                for(int j= 0; j < 10; j++){
//                    sb.append(parseInt(Math.random() * 10));
                    sb.append(new Random().nextInt(10));
                }
            }

            switch(bankType){
                case "CCB":
                    cardNo = "621700" + sb;
                    bankCode = "105";
                    break;
                case "CMBC":
                    cardNo = "621691" + sb;
                    bankCode = "305";
                    break;
                case "ABC":
                    cardNo = "622827" + sb;
                    bankCode = "103";
                    break;
                case "BCOM":
                    cardNo = "622262" + sb;
                    bankCode = "301";
                    break;
                case "CMB":
                    cardNo = "621486" + sb;
                    bankCode = "308";
                    break;
                case "SPDB":
                    cardNo = "622521" + sb;
                    bankCode = "310";
                    break;
                case "GDB":
                    cardNo = "622568" + sb;
                    bankCode = "306";
                    break;
                case "HXB":
                    cardNo = "622632" + sb;
                    bankCode = "304";
                    break;
                case "PAB":
                    cardNo = "622298" + sb;
                    bankCode = "783";
                    break;
                case "CITIC":
                    cardNo = "622696" + sb;
                    bankCode = "302";
                    break;
                case "ICBC":
                    cardNo = "620058" + sb;
                    bankCode = "102";
                    break;
                case "BOC":
                    cardNo = "620061" + sb;
                    bankCode = "104";
                    break;
                case "CIB":
                    cardNo = "622908" + sb;
                    bankCode = "309";
                    break;
                case "CEB":
                    cardNo = "622660" + sb;
                    bankCode = "303";
                    break;
                case "PSBC":
                    cardNo = "621799" + sb;
                    bankCode = "403";
                    break;
                default:
                    cardNo = "621700" + sb;
                    bankCode = "105";
            }

            if(luhmCheck(cardNo)){
                return cardNo;
            }
        }

    }



    private static  boolean luhmCheck(String cardNo) {
        return (luhnCheck(convertStrToInArr(cardNo)));
    }
    private static int[] convertStrToInArr(String cardNo) {
        if(null==cardNo)throw new IllegalArgumentException();
        int index = cardNo.length();
        int[] cardNoArr = new int[cardNo.length()];
        for(char c : cardNo.toCharArray())
        {
            cardNoArr[--index] = c - '0';
        }
        return cardNoArr;
    }

    /**
     * 校验的具体算法实现
     * @param cardNoArr
     * @return
     */
    private static boolean luhnCheck(int[] cardNoArr) {
        for(int i=1;i<cardNoArr.length;i+=2)
        {
            cardNoArr[i] <<= 1;
            cardNoArr[i] = cardNoArr[i]/10 + cardNoArr[i]%10;
        }
        int sum = 0;
        for(int i=0;i<cardNoArr.length;i++)
        {
            sum += cardNoArr[i];
            //System.out.print(cardNoArr[i]);
        }

        return sum % 10 == 0;
    }
}
