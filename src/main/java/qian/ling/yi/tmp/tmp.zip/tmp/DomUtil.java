package qian.ling.yi.tmp;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.SAXReader;
import org.dom4j.io.XMLWriter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.IOException;
import java.io.StringWriter;
import java.util.*;

/**
 * Created by baochunyu on 2016/8/8.
 */
public class DomUtil {

    private static final Logger logger = LoggerFactory.getLogger(DomUtil.class);


    public static Map xmlToMap(String xmlDoc) throws DocumentException {
        Map map = new HashMap();
        Document document = DocumentHelper.parseText(xmlDoc);
        Element root = document.getRootElement();
        elementToMap(root, map);
        return map;
    }

    public static void elementToMap(Element element, Map map) {
        if (element.isTextOnly()) {
            if (map.containsKey(element.getName())) {
                if (map.get(element.getName()) instanceof List) {
                    List list = (List) map.get(element.getName());
                    list.add(element.getText());
                } else if (map.get(element.getName()) instanceof String) {
                    String value = (String) map.get(element.getName());
                    map.remove(element.getName());
                    List list = new ArrayList();
                    list.add(value);
                    list.add(element.getText());
                    map.put(element.getName(), list);
                }
            } else {
                map.put(element.getName(), element.getText());
            }
        } else {
            for (Iterator it = element.elementIterator(); it.hasNext(); ) {
                Element child = (Element) it.next();
                if (child.isTextOnly()) {
                    elementToMap(child, map);
                } else {
                    if (map.containsKey(child.getName())) {
                        if (map.get(child.getName()) instanceof Map) {
                            Map origin = (Map) map.get(child.getName());
                            Map newMap = new HashMap();
                            map.remove(origin);
                            List list = new ArrayList();
                            elementToMap(child, newMap);
                            list.add(newMap);
                            list.add(origin);
                            map.put(child.getName(), list);
                        } else if (map.get(child.getName()) instanceof List) {
                            List list = (List) map.get(child.getName());
                            Map newMap = new HashMap();
                            elementToMap(child, newMap);
                            list.add(newMap);
                        }
                    } else {
                        Map newMap = new HashMap();
                        elementToMap(child, newMap);
                        map.put(child.getName(), newMap);
                    }
                }
            }
        }
    }

    public static String format(String text){

        StringWriter out=null;
        try{
            Document doc = DocumentHelper.parseText(text);
            OutputFormat format=OutputFormat.createPrettyPrint();
            out=new StringWriter();
            XMLWriter writer=new XMLWriter(out,format);
            writer.write(doc);
            return out.toString();
        } catch (Exception e){
            logger.error("DomUtil.format",e);
        } finally{
            try {
                out.close();
            } catch (IOException e) {
                logger.error("DomUtil.format",e);
            }
        }
        return null;
    }

    public static void main(String args[]) throws DocumentException {
        SAXReader reader = new SAXReader();
        Document document = reader.read(new File("e://settings.xml"));
        Map map = new HashMap();
        elementToMap(document.getRootElement(), map);
        System.out.println(map.toString());
        Map map1 = (Map) map.get("servers");
        List list = (List) map1.get("server");
        System.out.println(list.size());
        list.stream().forEach(node -> {
            Map map2 = (Map) node;
            System.out.println(map2.get("id"));
        });
        System.out.println(map.get("localRepository").toString());

    }
}
