package qian.ling.yi.tmp;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

//import com.nonobank.architecture.cache.CacheClient;
//import pay.biz.common.constants.PaymentConstant;
//import pay.biz.common.enums.BatchFileEnum;
//import pay.biz.common.enums.FileStausEnum;
//import pay.biz.gateway.communication.ftp.SFTPClient;
//import pay.biz.service.KqFtpFileService;
//import pay.model.po.KqFtpFile;
//import pay.util.CollectionUtil;
//import pay.util.DateUtil;

/**
 * 快钱批量文件
 * Created by liuguobin on 2016/12/30.
 */
@Component
public class KqBatchFileService {
    Logger logger = LoggerFactory.getLogger(KqBatchFileService.class);

    @Autowired
    FtpFileBuilder ftpFileBuilder;

//    @Autowired
//    KqFtpFileService kqFtpFileService;
//
//    @Autowired
//    SFTPClient sftpClient;
//
//    @Autowired
//    CacheClient cacheClient;

    @Value("${kq.ftp.confFile.auth}")
    String authPath;
    @Value("${kq.ftp.confFile.authRes}")
    String authResPath;
    @Value("${kq.ftp.confFile.authZxRes}")
    String authZxResPath;
    @Value("${kq.ftp.confFile.openAcc}")
    String openAccPath;
    @Value("${kq.ftp.confFile.openAccRes}")
    String openAccResPath;
    @Value("${kq.ftp.confFile.eve}")
    String evePath;
    @Value("${kq.ftp.confFile.eve_al}")
    String eveAlPath;
    @Value("${kq.ftp.confFile.eveTrdPay}")
    String eveTrdPayPath;
    @Value("${kq.ftp.confFile.bid}")
    String bidPath;
    @Value("${kq.ftp.confFile.bidRes}")
    String bidResPath;
    @Value("${kq.ftp.confFile.finTran}")
    String finTranPath;
    @Value("${kq.ftp.confFile.finTranRes}")
    String finTranResPath;
    @Value("${kq.ftp.confFile.repTran}")
    String repTranPath;
    @Value("${kq.ftp.confFile.repTranRes}")
    String repTranResPath;
    @Value("${kq.ftp.confFile.trQt}")
    String trQtPath;
    @Value("${kq.ftp.confFile.trQtRes}")
    String trQtResPath;
    @Value("${kq.ftp.confFile.trnCr}")
    String trnCrPath;
    @Value("${kq.ftp.confFile.trnCrRes}")
    String trnCrResPath;
    @Value("${kq.ftp.confFile.sigTran}")
    String sigTranPath;
    @Value("${kq.ftp.confFile.sigRes}")
    String sigResPath;

    @Value("${kq.ftp.local.upload.path}")
    String localUploadPath;

    @Value("${kq.ftp.local.download.path}")
    String localDownloadPath;

    @Value("${kq.ftp.remote.upload.path}")
    String remoteUploadPath;
    @Value("${kq.ftp.remote.download.path}")
    String remoteDownloadPath;

    @Value("${kq.ftp.bank.hs}")
    String bankHs;
    @Value("${kq.nuonuo.productId}")
    String kqProductId;
    @Value("${kq.platform.code}")
    String platformCode;
    @Value("${kq.cooperation.code}")
    String coopCode;

    private BatchFileEnum[] resultFileType = {
            BatchFileEnum.trQtRes,
            BatchFileEnum.appZxRes,
            BatchFileEnum.authRes,
            BatchFileEnum.authZxRes,
            BatchFileEnum.bidRes,
            BatchFileEnum.finTranRes,
            BatchFileEnum.repTranRes,
            BatchFileEnum.eve,
            BatchFileEnum.alEve,
            BatchFileEnum.trdPayEve,
            BatchFileEnum.sigRes,
            BatchFileEnum.trnCrRes
    };

    /**
     * 批量鉴权及开户
     *
     * @param values
     * @param fails
     * @return
     */
    public boolean uploadAuth(List<Map<String, String>> values, List<Map<String, String>> fails) {
        return createAndUploadFile(BatchFileEnum.auth, null, null, authPath, values, fails);
    }

    /**
     * 批量鉴权处理结果
     *
     * @param values
     * @param fails
     * @param fileName
     * @return
     */
    public boolean downloadAuthRes(List<Map<String, String>> values, List<String> fails, String fileName) {
        return downloadAndReadFile(BatchFileEnum.authRes, fileName, authResPath, values, fails);
    }

    /**
     * 批量鉴权开户处理结果
     *
     * @param values
     * @param fails
     * @param fileName
     * @return
     */
    public boolean downloadAuthZxRes(List<Map<String, String>> values, List<String> fails, String fileName) {
        //快钱调用银数的时候，生成的文件格式为 "UTF-8"，银数返回的结果也是 "UTF-8"
        return downloadAndReadFile(BatchFileEnum.authZxRes, fileName, authZxResPath, values, fails, "UTF-8");
    }

    /**
     * 批量开户
     *
     * @param values
     * @param fails
     * @return
     */
    public boolean uploadOpenAcc(List<Map<String, String>> values, List<Map<String, String>> fails) {
        return createAndUploadFile(BatchFileEnum.appZx, null, null, openAccPath, values, fails);
    }

    /**
     * 批量开户接口处理结果
     *
     * @param values
     * @param fails
     * @param fileName
     * @return
     */
    public boolean downloadOpenAccRs(List<Map<String, String>> values, List<String> fails, String fileName) {
        return downloadAndReadFile(BatchFileEnum.appZxRes, fileName, openAccResPath, values, fails);

    }

    /**
     * 债权转移
     * 用于上线时债权转让关系的导入；
     * 要迁移的项目状态为已经放款但未还款结清；
     * 无菜单，需要通过手工命令方式执行；
     * 按照债权迁移实施流程执行
     *
     * @param values
     * @param fails
     * @return
     */
    public boolean uploadBid(List<Map<String, String>> values, List<Map<String, String>> fails, String batch) {
        return createAndUploadFile(BatchFileEnum.bid, batch, null, bidPath, values, fails);

    }

    /**
     * 债权转移结果处理
     *
     * @param values
     * @param fails
     * @return
     */
    public boolean downloadBidRes(List<Map<String, String>> values, List<String> fails, String fileName) {
        return downloadAndReadFile(BatchFileEnum.bidRes, fileName, bidResPath, values, fails);

    }

    /**
     * 交易明细流水
     *
     * @param values
     * @param fails
     * @return
     */
    public boolean downloadEve(List<Map<String, String>> values, List<String> fails, String fileName) {
        return downloadAndReadFile(BatchFileEnum.eve, fileName, evePath, values, fails);

    }

    /**
     * 全流水
     *
     * @param values
     * @param fails
     * @param fileName
     * @return
     */
    public boolean downloadAlBid(List<Map<String, String>> values, List<String> fails, String fileName) {
        return downloadAndReadFile(BatchFileEnum.alEve, fileName, eveAlPath, values, fails);

    }


    /**
     * 第三方对账流水
     *
     * @param values
     * @param fails
     * @return
     */
    public boolean downloadTrdEve(List<Map<String, String>> values, List<String> fails, String fileName) {
        return downloadAndReadFile(BatchFileEnum.trdPayEve, fileName, eveTrdPayPath, values, fails);

    }

    /**
     * 融资扣款
     *
     * @param values
     * @param fails
     * @return
     */
    public boolean uploadFinTran(List<Map<String, String>> values, List<Map<String, String>> fails, String batch, String date) {
        return createAndUploadFile(BatchFileEnum.finTran, batch, date, finTranPath, values, fails);

    }

    /**
     * 融资扣款结果
     *
     * @param values
     * @param fails
     * @param fileName
     * @return
     */
    public boolean downloadFinTranRes(List<Map<String, String>> values, List<String> fails, String fileName) {
        return downloadAndReadFile(BatchFileEnum.finTran, fileName, finTranResPath, values, fails);

    }


    /**
     * 到期还款
     *
     * @param values
     * @param fails
     * @return
     */
    public boolean uploadRepTran(List<Map<String, String>> values, List<Map<String, String>> fails, String batch, String date) {
        return createAndUploadFile(BatchFileEnum.repTran, batch, date, repTranPath, values, fails);

    }

    /**
     * 到期还款结果
     *
     * @param values
     * @param fails
     * @param fileName
     * @return
     */
    public boolean downloadRepTranRes(List<Map<String, String>> values, List<String> fails, String fileName) {
        return downloadAndReadFile(BatchFileEnum.repTran, fileName, repTranResPath, values, fails);

    }


    /**
     * 发红包
     * [加息券收益发放]
     * 用于P2P存管账户的批量红包发放，资金从P2P平台的红包账户转出
     * 是跟快钱约定时间，还是接口通知
     *
     * @param values
     * @param fails
     * @return
     */
    public boolean uploadTrQt(List<Map<String, String>> values, List<Map<String, String>> fails, String batch, String date) {
        return createAndUploadFile(BatchFileEnum.trQt, batch, date, trQtPath, values, fails);

    }

    /**
     * 发红包结果
     *
     * @param values
     * @param fails
     * @param fileName
     * @return
     */
    public boolean downloadTrQtRes(List<Map<String, String>> values, List<String> fails, String fileName) {
        return downloadAndReadFile(BatchFileEnum.trQtRes, fileName, trQtResPath, values, fails);

    }

    /**
     * 批量债权转让文件接口
     * 承接方扣款金额从承接方可用余额扣除
     *
     * @param values
     * @param fails
     * @return
     */
    public boolean uploadTrnCr(List<Map<String, String>> values, List<Map<String, String>> fails, String batch, String date) {
        return createAndUploadFile(BatchFileEnum.trnCr, batch, date, trnCrPath, values, fails);

    }

    /**
     * 批量债权转让结果文件接口
     *
     * @param values
     * @param fails
     * @param fileName
     * @return
     */
    public boolean downloadTrnCrRes(List<Map<String, String>> values, List<String> fails, String fileName) {
        return downloadAndReadFile(BatchFileEnum.trnCrRes, fileName, trnCrResPath, values, fails);

    }

    /**
     * 签约关系迁移文件接口
     *
     * @param values
     * @param fails
     * @return
     */
    public boolean uploadSigTran(List<Map<String, String>> values, List<Map<String, String>> fails, String batch, String date) {
        return createAndUploadFile(BatchFileEnum.sigTran, batch, date, sigTranPath, values, fails);

    }

    /**
     * 签约关系迁移结果文件接口
     *
     * @param values
     * @param fails
     * @param fileName
     * @return
     */
    public boolean downloadSigRes(List<Map<String, String>> values, List<String> fails, String fileName) {
        return downloadAndReadFile(BatchFileEnum.sigRes, fileName, sigResPath, values, fails);

    }

    /**
     * 遍历远程服务器的新的文件列表
     *
     * @return
     */
//    public List<String> listNewFile() {
//        Vector<ChannelSftp.LsEntry> lsEntries = listNewRemoteFile(remoteDownloadPath /*+ "/" + DateUtil.getCurrentDate()*/);
//        if (null != lsEntries) {
//            List<String> files = new ArrayList<>(lsEntries.size());
//            lsEntries.forEach(lsEntry -> files.add(lsEntry.getFilename()));
//            return files;
//        }
//        return new ArrayList<>();
//    }

    /**
     * 遍历远程服务器的新的文件列表
     *
     * @return
     */
//    public List<KqFtpFile> listCreateFileTask(String batchFileEnum, String startTime, String endTime, String status, int size) {
////        return kqFtpFileService.listFiles(batchFileEnum, "1", startTime, endTime, status, size);
//    }

    //根据文件类型，进行存储
    public boolean processFile(String[] files) {
        for (String fileName : files) {
            for (BatchFileEnum fileEnum : resultFileType) {
                if (fileName.contains(fileEnum.getFileName())) {
                    if (!downloadFile(fileEnum, fileName, null)) return false;
                    break;
                }
            }
        }
        return true;
    }

    /**
     * 待传输名称确认
     *
     * @param fileType
     * @param fileName
     * @return
     */
    String getLocalFilePath(BatchFileEnum fileType, String fileName) {

        switch (fileType) {
            case auth:
                return localUploadPath + BatchFileEnum.auth.name() + "/" + DateUtil.getCurrentDate() + "/" + fileName;
            case authRes:
                return localDownloadPath + BatchFileEnum.authRes.name() + "/" + DateUtil.getCurrentDate() + "/" + fileName;
            case authZxRes:
                return localDownloadPath + BatchFileEnum.authZxRes.name() + "/" + DateUtil.getCurrentDate() + "/" + fileName;
//            case appZx:
//                return localUploadPath + BatchFileEnum.appZx.name() + "/" + DateUtil.getCurrentDate() + "/" + fileName;
//            case appZxRes:
//                return localDownloadPath + BatchFileEnum.appZxRes.name() + "/" + fileName;
            case eve:
                return localDownloadPath + BatchFileEnum.eve.name() + "/" + DateUtil.getCurrentDate() + "/" + fileName;
            case alEve:
                return localDownloadPath + BatchFileEnum.alEve.name() + "/" + DateUtil.getCurrentDate() + "/" + fileName;
            case trdPayEve:
                return localDownloadPath + BatchFileEnum.trdPayEve.name() + "/" + DateUtil.getCurrentDate() + "/" + fileName;
            case bid:
                return localUploadPath + BatchFileEnum.bid.name() + "/" + DateUtil.getCurrentDate() + "/" + fileName;
            case bidRes:
                return localDownloadPath + BatchFileEnum.bidRes.name() + "/" + DateUtil.getCurrentDate() + "/" + fileName;
            case finTran:
                return localUploadPath + BatchFileEnum.finTran.name() + "/" + DateUtil.getCurrentDate() + "/" + fileName;
            case finTranRes:
                return localDownloadPath + BatchFileEnum.finTranRes.name() + "/" + DateUtil.getCurrentDate() + "/" + fileName;
            case repTran:
                return localUploadPath + BatchFileEnum.repTran.name() + "/" + DateUtil.getCurrentDate() + "/" + fileName;
            case repTranRes:
                return localDownloadPath + BatchFileEnum.repTranRes.name() + "/" + DateUtil.getCurrentDate() + "/" + fileName;
            case trQt:
                return localUploadPath + BatchFileEnum.trQt.name() + "/" + DateUtil.getCurrentDate() + "/" + fileName;
            case trQtRes:
                return localDownloadPath + BatchFileEnum.trQtRes.name() + "/" + DateUtil.getCurrentDate() + "/" + fileName;
            case trnCr:
                return localUploadPath + BatchFileEnum.trnCr.name() + "/" + DateUtil.getCurrentDate() + "/" + fileName;
            case trnCrRes:
                return localDownloadPath + BatchFileEnum.trnCrRes.name() + "/" + DateUtil.getCurrentDate() + "/" + fileName;
            case sigTran:
                return localUploadPath + BatchFileEnum.sigTran.name() + "/" + DateUtil.getCurrentDate() + "/" + fileName;
            case sigRes:
                return localDownloadPath + BatchFileEnum.sigRes.name() + "/" + DateUtil.getCurrentDate() + "/" + fileName;
            default:
                return localUploadPath + DateUtil.getCurrentDate() + "/" + fileName;
        }

    }

    String getFileName(BatchFileEnum fileEnum, String batch, String date) {
        switch (fileEnum) {
            case auth:
                return bankHs + "-BAUTH" + kqProductId + "-" + DateUtil.getCurrentTime() + "-" + DateUtil.getCurrentDate();
            case appZx:
                return bankHs + "-APPZX" + kqProductId + "-" + DateUtil.getCurrentTime() + "-" + DateUtil.getCurrentDate();
            case bid:
                return bankHs + "-BID-" + batch + "-" + DateUtil.getCurrentDate();
            case finTran:
                return bankHs + "-" + platformCode + "-Z01-FINTRAN-" + batch + "-" + date;
            case repTran:
                return bankHs + "-" + platformCode + "-Z01-REPTRAN-" + DateUtil.getCurrentTime() + "-" + date;
            case trQt:
                return bankHs + "-TRQT-" + coopCode + "-" + DateUtil.getCurrentTime() + "-" + DateUtil.getCurrentDate();
            case trnCr:
                return bankHs + "-" + platformCode + "-TRNCR-" + DateUtil.getCurrentTime() + "-" + DateUtil.getCurrentDate();
            case sigTran:
                return bankHs + "-" + platformCode + "-SIGTRAN-" + DateUtil.getCurrentTime() + "-" + DateUtil.getCurrentDate();
            default:
                return fileEnum.name();
        }
    }

    /**
     * 上传文件
     *
     * @param localFile
     * @param remoteFile
     * @return
     */
    public boolean uploadFile(String localFile, String remoteFile) {
//        if (!sftpClient.uploadFile(localFile, remoteFile)) {
//            logger.info("上传本地文件 {} 至 远程 {} 出错", localFile, remoteFile);
//            return false;
//        }
        logger.info("上传本地文件 {} 至 远程 {} 成功", localFile, remoteFile);
        return true;
    }

    /**
     * 下载文件
     *
     * @param batchFileEnum
     * @param fileName
     * @param localPath
     * @return
     */
    public boolean downloadFile(BatchFileEnum batchFileEnum, String fileName, String localPath) {
        String remotePath = remoteDownloadPath + fileName;
        if (StringUtil.isEmpty(localPath)) {
            localPath = getLocalFilePath(batchFileEnum, fileName);
        }

        KqFtpFile kqFtpFile = new KqFtpFile();
        kqFtpFile.setLocalPath(localPath);
        kqFtpFile.setRemotePath(remotePath);
        kqFtpFile.setProduct(batchFileEnum.name());
        kqFtpFile.setType(2);
        kqFtpFile.setName(fileName);
        kqFtpFile.setRemark("");

        boolean suc = true;
//        if (!sftpClient.download(remotePath, localPath)) {
//            logger.error("下载远程文件出错：{}", remotePath);
//            suc = false;
//            kqFtpFile.setStatus(FileStausEnum.DOWN_FAIL.name());
//        } else {
//            kqFtpFile.setStatus(FileStausEnum.DOWN_SUC.name());
//        }
//        kqFtpFileService.saveKqFtpFile(kqFtpFile);
//
//        cacheClient.rpush(PaymentConstant.CACHE_KQ_FILE_KEY + DateUtil.getCurrentDate(), fileName);
        return suc;
    }

    /**
     * 保存数据并上传文件
     *
     * @param batchFileEnum
     * @param confFile
     * @param values
     * @param fails
     * @return
     */
    public boolean createAndUploadFile(BatchFileEnum batchFileEnum, String batch, String date, String confFile, List<Map<String, String>> values, List<Map<String, String>> fails) {
        String fileName = getFileName(batchFileEnum, batch, date);
        String remotePath = remoteUploadPath + fileName;
        String localPath = getLocalFilePath(batchFileEnum, fileName);

        KqFtpFile kqFtpFile = new KqFtpFile();
        kqFtpFile.setLocalPath(localPath);
        kqFtpFile.setRemotePath(remotePath);
        kqFtpFile.setProduct(batchFileEnum.name());
        kqFtpFile.setType(1);
        kqFtpFile.setName(fileName);
        kqFtpFile.setRemark("");

        boolean suc = true;

        if (!ftpFileBuilder.createFile(localPath, confFile, values, fails)) {
            suc = false;
            kqFtpFile.setStatus(FileStausEnum.CREATE_FAIL.name());
        }

        if (!uploadFile(localPath, remotePath)) {
            suc = false;
            kqFtpFile.setStatus(FileStausEnum.UPLOAD_FAIL.name());
        } else {
            kqFtpFile.setStatus(FileStausEnum.UPLOAD_SUC.name());
        }

//        kqFtpFileService.saveKqFtpFile(kqFtpFile);
        return suc;
    }

    /**
     * 保存数据并上传文件
     *
     * @param batchFileEnum
     * @return
     */
    public void saveKqFile(BatchFileEnum batchFileEnum, String batch, String date, int count) {
        String fileName = getFileName(batchFileEnum, batch, date);
        String remotePath = remoteUploadPath + fileName;
        String localPath = getLocalFilePath(batchFileEnum, fileName);

        KqFtpFile kqFtpFile = new KqFtpFile();
        kqFtpFile.setLocalPath(localPath);
        kqFtpFile.setRemotePath(remotePath);
        kqFtpFile.setProduct(batchFileEnum.name());
        kqFtpFile.setType(1);
        kqFtpFile.setName(fileName);
        kqFtpFile.setCount(count);
        kqFtpFile.setBatch(batch);
        kqFtpFile.setStatus(FileStausEnum.INIT.name());
        kqFtpFile.setRemark("");

//        kqFtpFileService.saveKqFtpFile(kqFtpFile);
    }

    /**
     * 下载并读取远程文件
     *
     * @param confFile
     * @param values
     * @param fails
     * @return
     */
    public boolean downloadAndReadFile(BatchFileEnum batchFileEnum, String fileName, String confFile, List<Map<String, String>> values, List<String> fails) {
        return downloadAndReadFile(batchFileEnum, fileName, confFile, values, fails, "GBK");
    }

    /**
     * 下载并读取远程文件
     *
     * @param confFile
     * @param values
     * @param fails
     * @return
     */
    public boolean downloadAndReadFile(BatchFileEnum batchFileEnum, String fileName, String confFile, List<Map<String, String>> values, List<String> fails, String charset) {
        String localPath = getLocalFilePath(batchFileEnum, fileName);
        if (!downloadFile(batchFileEnum, fileName, localPath)) {
            return false;
        }
        return ftpFileBuilder.readCharsetFile(localPath, confFile, values, fails, charset);
    }


    /****************************** 流程生成文件需要 ***************************/

    /**
     * 发红包
     * [加息券收益发放]
     * 用于P2P存管账户的批量红包发放，资金从P2P平台的红包账户转出
     * 是跟快钱约定时间，还是接口通知
     *
     * @param fails
     * @return
     */
    public boolean uploadTrQt(KqFtpFile kqFtpFile, List<Map<String, String>> values, List<Map<String, String>> fails) {
        return createAndUploadFile(kqFtpFile, trQtPath, values, fails);
    }



    /**
     * 保存数据并上传文件
     *
     * @param confFile
     * @param values
     * @param fails
     * @return
     */
    public boolean createAndUploadFile(KqFtpFile kqFtpFile, String confFile, List<Map<String, String>> values, List<Map<String, String>> fails) {
//        String fileName = getFileName(batchFileEnum, batch, date);

        boolean suc = true;

        String status = null;
        if (!ftpFileBuilder.createFile(kqFtpFile.getLocalPath(), confFile, values, fails)) {
            suc = false;
            status= FileStausEnum.CREATE_FAIL.name();
        }

        if (!uploadFile(kqFtpFile.getLocalPath(), kqFtpFile.getRemotePath())) {
            suc = false;
            status = FileStausEnum.UPLOAD_FAIL.name();
        } else {
            status = FileStausEnum.UPLOAD_SUC.name();
        }

//        kqFtpFileService.updateFileStatus(kqFtpFile.getId(), status);
        return suc;
    }
}